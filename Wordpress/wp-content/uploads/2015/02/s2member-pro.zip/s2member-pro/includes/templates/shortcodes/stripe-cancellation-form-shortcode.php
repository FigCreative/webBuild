<?php
if(!defined('WPINC')) // MUST have WordPress.
	exit("Do not access this file directly.");
?>

[s2Member-Pro-Stripe-Form cancel="1" desc="<?php echo esc_attr (_x ("This will cancel your account. Are you sure?", "s2member-front", "s2member")); ?>" unsub="0" captcha="0" /]