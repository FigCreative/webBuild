<?php
if(!defined('WPINC')) // MUST have WordPress.
	exit("Do not access this file directly.");
?>

[s2Member-Pro-Google-Button modify="1" cancel="1" image="default" output="anchor" /]